import * as i0 from "@angular/core";
import { OnInit } from "@angular/core";
export declare class HalloweenUi implements OnInit {
  constructor();
  ngOnInit(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<HalloweenUi, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<HalloweenUi, "lib-halloween-ui", never, {}, {}, never, never, true, never>;
}
export declare class MonsterCardComponent {
  titulo: string;
  descripcion: string;
  imagen: string;
  boton: string;
  static ɵfac: i0.ɵɵFactoryDeclaration<MonsterCardComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MonsterCardComponent, "lib-monster-card", never, {
    "titulo": {
      "alias": "titulo";
      "required": false;
    };
    "descripcion": {
      "alias": "descripcion";
      "required": false;
    };
    "imagen": {
      "alias": "imagen";
      "required": false;
    };
    "boton": {
      "alias": "boton";
      "required": false;
    };
  }, {}, never, never, true, never>;
}