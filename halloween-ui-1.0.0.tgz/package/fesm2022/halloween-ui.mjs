import * as i0 from "@angular/core";
import { Component, Input } from "@angular/core";
var HalloweenUi = class HalloweenUi {
	constructor() {}
	ngOnInit() {}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.3.0",
			ngImport: i0,
			type: HalloweenUi,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.3.0",
			type: HalloweenUi,
			isStandalone: true,
			selector: "lib-halloween-ui",
			ngImport: i0,
			template: "<p>halloween-ui works!</p>\n",
			styles: [""]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.3.0",
	ngImport: i0,
	type: HalloweenUi,
	decorators: [{
		type: Component,
		args: [{
			selector: "lib-halloween-ui",
			imports: [],
			template: "<p>halloween-ui works!</p>\n"
		}]
	}],
	ctorParameters: () => []
});
var MonsterCardComponent = class MonsterCardComponent {
	constructor() {
		this.titulo = "";
		this.descripcion = "";
		this.imagen = "";
		this.boton = "Descubrir";
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.3.0",
			ngImport: i0,
			type: MonsterCardComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.3.0",
			type: MonsterCardComponent,
			isStandalone: true,
			selector: "lib-monster-card",
			inputs: {
				titulo: "titulo",
				descripcion: "descripcion",
				imagen: "imagen",
				boton: "boton"
			},
			ngImport: i0,
			template: "<div class=\"tarjeta\">\n  <img [src]=\"imagen\" [alt]=\"titulo\">\n\n  <h2>{{ titulo }}</h2>\n\n  <p>{{ descripcion }}</p>\n\n  <button type=\"button\">\n    {{ boton }}\n  </button>\n</div>\n",
			styles: [".tarjeta{background:linear-gradient(145deg,#35204b,#21132f);border:1px solid #7952a8;border-radius:18px;padding:22px;margin:25px 0;text-align:center;color:#fff;box-shadow:0 8px 20px #0000004d}.tarjeta img{width:170px;height:170px;object-fit:contain;margin-bottom:12px}.tarjeta h2{color:#c49aff;font-size:24px;font-weight:700;margin:10px 0}.tarjeta p{color:#d0c5dc;font-size:15px;line-height:1.6}.tarjeta button{background:#a8e063;color:#160d24;border:none;border-radius:10px;padding:13px 24px;margin-top:12px;font-size:14px;font-weight:700;cursor:pointer;transition:transform .2s}.tarjeta button:active{transform:scale(.96)}\n"]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.3.0",
	ngImport: i0,
	type: MonsterCardComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "lib-monster-card",
			standalone: true,
			imports: [],
			template: "<div class=\"tarjeta\">\n  <img [src]=\"imagen\" [alt]=\"titulo\">\n\n  <h2>{{ titulo }}</h2>\n\n  <p>{{ descripcion }}</p>\n\n  <button type=\"button\">\n    {{ boton }}\n  </button>\n</div>\n",
			styles: [".tarjeta{background:linear-gradient(145deg,#35204b,#21132f);border:1px solid #7952a8;border-radius:18px;padding:22px;margin:25px 0;text-align:center;color:#fff;box-shadow:0 8px 20px #0000004d}.tarjeta img{width:170px;height:170px;object-fit:contain;margin-bottom:12px}.tarjeta h2{color:#c49aff;font-size:24px;font-weight:700;margin:10px 0}.tarjeta p{color:#d0c5dc;font-size:15px;line-height:1.6}.tarjeta button{background:#a8e063;color:#160d24;border:none;border-radius:10px;padding:13px 24px;margin-top:12px;font-size:14px;font-weight:700;cursor:pointer;transition:transform .2s}.tarjeta button:active{transform:scale(.96)}\n"]
		}]
	}],
	propDecorators: {
		titulo: [{ type: Input }],
		descripcion: [{ type: Input }],
		imagen: [{ type: Input }],
		boton: [{ type: Input }]
	}
});
export { HalloweenUi, MonsterCardComponent };

//# sourceMappingURL=halloween-ui.mjs.map